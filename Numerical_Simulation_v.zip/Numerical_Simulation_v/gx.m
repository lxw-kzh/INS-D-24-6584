function [res] = gx(x)
D=[1.25, -3.2, -3.2;
   -3.2, 1.1, -4.4;
   -3.2, 4.4, 1];
res=-x+D*[hx(x(1)), hx(x(2)), hx(x(3))]';
end

