clear all;
clc;

% outer coupling matrices
B1 = [-3, 1.5, 1.5;
      1, -3, 2;
      3, 1, -4];

B2 = [0, 0, 0;
      0, -3, 3;
      1.5, 0.5, -2];

B3 = [-3.5, 1.5, 2;
      -0.5, 0.5, 0;
      0.5, 3.5, -4];

% inner coupling matrices
C1 = [9, 0, 0.3;
      0, 9, 0;
      0.3, 0, 8];

C2 = [7, 1, 0.2;
      1, -0.5, 0.2;
      0.2, 0.2, 6];

C3 = [9, 1, 0.2;
      1, 3, 0.2;
      0.2, 0.2, 2];

C = [4, 0.5, 0;
     0.5, 5, 1;
     0, 1, 6];

      
B_11 = C1(1,1)*B1 + C2(1,1)*B2 + C3(1,1)*B3;
B_12 = C1(1,2)*B1 + C2(1,2)*B2 + C3(1,2)*B3;
B_13 = C1(1,3)*B1 + C2(1,3)*B2 + C3(1,3)*B3;
B_21 = C1(2,1)*B1 + C2(2,1)*B2 + C3(2,1)*B3;
B_22 = C1(2,2)*B1 + C2(2,2)*B2 + C3(2,2)*B3;
B_23 = C1(2,3)*B1 + C2(2,3)*B2 + C3(2,3)*B3;
B_31 = C1(3,1)*B1 + C2(3,1)*B2 + C3(3,1)*B3;
B_32 = C1(3,2)*B1 + C2(3,2)*B2 + C3(3,2)*B3;
B_33 = C1(3,3)*B1 + C2(3,3)*B2 + C3(3,3)*B3;

[eigenVector1, eigenValue1] = eig(B_11');
eigenVec1 = eigenVector1(:, 1);
ome1 = eigenVec1 / sum(eigenVec1);
[eigenVector2, eigenValue2] = eig(B_22');
eigenVec2 = eigenVector2(:, 1);
ome2 = eigenVec2 / sum(eigenVec2);
[eigenVector3, eigenValue3] = eig(B_33');
eigenVec3 = eigenVector3(:, 1);
ome3 = eigenVec3 / sum(eigenVec3);

B_11 = B_11 - diag([C(1,1), C(1,1), C(1,1)]);
B_12 = B_12 - diag([C(1,2), C(1,2), C(1,2)]);
B_13 = B_13 - diag([C(1,3), C(1,3), C(1,3)]);
B_21 = B_21 - diag([C(2,1), C(2,1), C(2,1)]);
B_22 = B_22 - diag([C(2,2), C(2,2), C(2,2)]);
B_23 = B_23 - diag([C(2,3), C(2,3), C(2,3)]);
B_31 = B_31 - diag([C(3,1), C(3,1), C(3,1)]);
B_32 = B_32 - diag([C(3,2), C(3,2), C(3,2)]);
B_33 = B_33 - diag([C(3,3), C(3,3), C(3,3)]);

I1 = diag(ome1);
I2 = diag(ome2);
I3 = diag(ome3);

Z = zeros(3, 3);
I = [I1, Z, Z;
     Z, I2, Z;
     Z, Z, I3];

B = [B_11, B_12, B_13;
     B_21, B_22, B_23;
     B_31, B_32, B_33];
 
BB = (I*B + B'*I) / 2;

eig(BB);

rho = 2.2;
mu = 5.5682;
res1 = mu * 0.4546 + rho * (-1.2232) % for finite-time

res2 = (mu+0.5)*2^2/1.2232 % for prescribed-time
