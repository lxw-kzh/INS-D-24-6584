clear all;
clc;

% outer coupling matrices
B1 = [-3, 1.5, 1.5;
      1, -3, 2;
      3, 1, -4];

B2 = [0, 0, 0;
      0, -3, 3;
      1.5, 0.5, -2];

B3 = [-3.5, 1.5, 2;
      -0.5, 0.5, 0;
      0.5, 3.5, -4];

% inner coupling matrices
C1 = [9, 0, 0.3;
      0, 9, 0;
      0.3, 0, 8];

C2 = [7, 1, 0.2;
      1, -0.5, 0.2;
      0.2, 0.2, 6];

C3 = [9, 1, 0.2;
      1, 3, 0.2;
      0.2, 0.2, 2];

C = [4, 0.5, 0;
     0.5, 5, 1;
     0, 1, 6];

B_11 = C1(1,1)*B1 + C2(1,1)*B2 + C3(1,1)*B3 - diag([C(1,1), C(1,1), C(1,1)]);
B_12 = C1(1,2)*B1 + C2(1,2)*B2 + C3(1,2)*B3 - diag([C(1,2), C(1,2), C(1,2)]);
B_13 = C1(1,3)*B1 + C2(1,3)*B2 + C3(1,3)*B3 - diag([C(1,3), C(1,3), C(1,3)]);
B_21 = C1(2,1)*B1 + C2(2,1)*B2 + C3(2,1)*B3 - diag([C(2,1), C(2,1), C(2,1)]);
B_22 = C1(2,2)*B1 + C2(2,2)*B2 + C3(2,2)*B3 - diag([C(2,2), C(2,2), C(2,2)]);
B_23 = C1(2,3)*B1 + C2(2,3)*B2 + C3(2,3)*B3 - diag([C(2,3), C(2,3), C(2,3)]);
B_31 = C1(3,1)*B1 + C2(3,1)*B2 + C3(3,1)*B3 - diag([C(3,1), C(3,1), C(3,1)]);
B_32 = C1(3,2)*B1 + C2(3,2)*B2 + C3(3,2)*B3 - diag([C(3,2), C(3,2), C(3,2)]);
B_33 = C1(3,3)*B1 + C2(3,3)*B2 + C3(3,3)*B3 - diag([C(3,3), C(3,3), C(3,3)]);

B = [B_11, B_12, B_13;
     B_21, B_22, B_23;
     B_31, B_32, B_33];


T = 2;
dt = 0.0001;
step = round(T / dt);
N = 3; % number of nodes
W = 3; % number of weights
dm = 3;% dimension
rho = 0.2;% coupling strength
r = 2;


z_axis = zeros(1, step);
for i = 2 : step
   z_axis(i) =  dt * (i - 1);
end

z0_1 = [1, 2, 3]';
z0_2 = [2, 3, 4]';
z0_3 = [3, 4, 5]';


zbar1 = zeros(dm, step);% first node
zbar2 = zeros(dm, step);% second node
zbar3 = zeros(dm, step);% third node
zbar1(:, 1) = z0_1;
zbar2(:, 1) = z0_2;
zbar3(:, 1) = z0_3;

% initial values
z0_0 = [1, 1, 1]';
zbar0 = zeros(dm, step);
zbar0(:, 1) = z0_0;

ebar = zeros(1, step);
ebar(1) = sqrt((z0_1 - z0_0)' * (z0_1 - z0_0) + (z0_2 - z0_0)' * (z0_2 - z0_0) + (z0_3 - z0_0)' * (z0_3 - z0_0));

En = 0;
p = 2;

ome1 = [0.2483, 0.4546, 0.2971];
ome2 = [0.2898, 0.4367, 0.2735];
ome3 = [0.4049, 0.2845, 0.3106];  
V0 = 1/2*(ome1(1)*(z0_1(1)-z0_0(1))^2+ome1(2)*(z0_1(2)-z0_0(2))^2+ome1(3)*(z0_1(3)-z0_0(3))^2 ...
     + ome2(1)*(z0_2(1)-z0_0(1))^2+ome2(2)*(z0_2(2)-z0_0(2))^2+ome2(3)*(z0_2(3)-z0_0(3))^2 ...
     + ome3(1)*(z0_3(1)-z0_0(1))^2+ome3(2)*(z0_3(2)-z0_0(2))^2+ome3(3)*(z0_3(3)-z0_0(3))^2);
mu = 5.5682;
gamma1 = 2*mu;
gamma2 = -2*(-1.2232)*rho;
gamma3 = sum(abs(ones(1,9)*B).^p)*(3*3)^(1-min(p,2)/2)*2^(p/2)*rho^2/0.24828;
gamma5 = gamma3*V0*exp(gamma1*T+gamma2/T)/(T^(p*r-1)*(r-1));

En_est = gamma5*generalized_expint(r*(1-p/(r-1)),p*gamma2/(2*T^(r-1)*(r-1)));

for i = 1 : (step - 1)

    if(i>1)
        if(ebar(i-1)<=1e-10)
        zbar1(:, i + 1) = zbar1(:, i);
        zbar2(:, i + 1) = zbar2(:, i);
        zbar3(:, i + 1) = zbar3(:, i);
        continue;
        end
    end

    tmp = zeros(dm, N);

    mut = 1/(T-i*dt)^r;
    
    for j = 1 : N
        tmp(:, j) = rho * mut * (B1(j, 1) * C1 * zbar1(:, i)...
                    + B1(j, 2) * C1 * zbar2(:, i) + B1(j, 3) * C1 * zbar3(:, i)...
                    + B2(j, 1) * C2 * zbar1(:, i) + B2(j, 2) * C2 * zbar2(:, i)...
                    + B2(j, 3) * C2 * zbar3(:, i) + B3(j, 1) * C3 * zbar1(:, i)...
                    + B3(j, 2) * C3 * zbar2(:, i) + B3(j, 3) * C3 * zbar3(:, i));

        En = En + dt * (sum(abs(rho*mut*B1(j, 1)*C1*(zbar1(:, i)-zbar0(:, i))).^p) ...
             + sum(abs(rho*mut*B1(j, 2) * C1 * (zbar2(:, i)-zbar0(:, i))).^p) ...
             + sum(abs(rho*mut*B1(j, 2) * C1 * (zbar3(:, i)-zbar0(:, i))).^p) ...
             + sum(abs(rho*mut*B2(j, 2) * C2 * (zbar1(:, i)-zbar0(:, i))).^p) ...
             + sum(abs(rho*mut*B2(j, 2) * C2 * (zbar2(:, i)-zbar0(:, i))).^p) ...
             + sum(abs(rho*mut*B2(j, 2) * C2 * (zbar3(:, i)-zbar0(:, i))).^p) ...
             + sum(abs(rho*mut*B3(j, 2) * C3 * (zbar1(:, i)-zbar0(:, i))).^p) ...
             + sum(abs(rho*mut*B3(j, 2) * C3 * (zbar2(:, i)-zbar0(:, i))).^p) ...
             + sum(abs(rho*mut*B3(j, 2) * C3 * (zbar3(:, i)-zbar0(:, i))).^p));
    end
    tmp(:, 1) = tmp(:, 1) - rho * mut * C * (zbar1(:, i)-zbar0(:, i));
    tmp(:, 2) = tmp(:, 2) - rho * mut * C * (zbar2(:, i)-zbar0(:, i));
    tmp(:, 3) = tmp(:, 3) - rho * mut * C * (zbar3(:, i)-zbar0(:, i));
        
    zbar0(:, i + 1) = zbar0(:, i) + gx(zbar0(:, i)) * dt;
    zbar1(:, i + 1) = zbar1(:, i) + (gx(zbar1(:, i)) + tmp(:, 1)) * dt;
    zbar2(:, i + 1) = zbar2(:, i) + (gx(zbar2(:, i)) + tmp(:, 2)) * dt;
    zbar3(:, i + 1) = zbar3(:, i) + (gx(zbar3(:, i)) + tmp(:, 3)) * dt;
    ebar(i + 1) = sqrt((zbar1(:, i + 1) - zbar0(:, i + 1))' * (zbar1(:, i + 1) - zbar0(:, i + 1))...
                + (zbar2(:, i + 1) - zbar0(:, i + 1))' * (zbar2(:, i + 1) - zbar0(:, i + 1))...
                + (zbar3(:, i + 1) - zbar0(:, i + 1))' * (zbar3(:, i + 1) - zbar0(:, i + 1)));

    En = En - dt * (sum(abs(rho*mut*C*(zbar1(:, i)-zbar0(:, i))).^p) ...
         + sum(abs(rho*mut*C*(zbar2(:, i)-zbar0(:, i))).^p) ...
         + sum(abs(rho*mut*C*(zbar3(:, i)-zbar0(:, i))).^p));

end

En

plot(z_axis, ebar, '-', 'LineWidth', 2);
xlabel('Time t');
ylabel('E');
xlim([0, T]);
hold on;


